﻿using Agenda.BLL;
using Agenda.BLL.Entities;
using Agenda.BLL.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Agenda.UI
{
    /// <summary>
    /// Interação lógica para MainWindow.xam
    /// </summary>
    public partial class MainWindow : Window
    {
        private UserService _userService;

        public MainWindow()
        {
            InitializeComponent();
            gridUsers.CanUserAddRows = false;
            Context ctx = new Context();
            this._userService = new UserService(ctx);
            ClearScreen(TxtAddress, TxtCity, TxtName, TxtNeighborhood, TxtState, TxtZipCode);
            PopulateUsers();
        }



        private void PopulateUsers()
        {
            gridUsers.ItemsSource = this._userService.SelectUsers();
        }

        private void DeleteUser(object sender, RoutedEventArgs e)
        {
            var currentUser = ((User)(sender as Button).DataContext);
            _userService.RemoveUser(currentUser);
            PopulateUsers();
        }

        private void UpdateUser(object sender, RoutedEventArgs e)
        {
            var currentUser = ((User)(sender as Button).DataContext);
            tabControl.SelectedIndex = 1;
            UserToScreen(currentUser);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            User user = new User();
            user.Id = int.Parse(lblId.Content.ToString());
            user.Address = TxtAddress.Text;
            user.City = TxtCity.Text;
            user.Name = TxtName.Text;
            user.Neighborhood = TxtNeighborhood.Text;
            user.State = TxtState.Text;
            user.ZipCode = TxtZipCode.Text;
            if (this._userService.Save(user))
            {
                PopulateUsers();
            }
            ClearScreen(TxtAddress, TxtCity, TxtName, TxtNeighborhood, TxtState, TxtZipCode);
            tabControl.SelectedIndex = 0;
        }

        private void ClearScreen(params TextBox[] data)
        {
            lblId.Content = "0";
            foreach (var item in data)
            {
                item.Clear();
            }
        }

        private void UserToScreen(User user)
        {
            lblId.Content = user.Id.ToString();
            TxtAddress.Text = user.Address;
            TxtCity.Text = user.City;
            TxtName.Text = user.Name;
            TxtNeighborhood.Text = user.Neighborhood;
            TxtState.Text = user.State;
            TxtZipCode.Text = user.ZipCode;
        }
    }
}
