﻿using Agenda.BLL.Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agenda.BLL
{
    public class Context : DbContext
    {
        public Context() : base("default")
        {

        }

        public DbSet<User> Users { get; set; }

        public DbSet<Schedule> Schedules { get; set; }

        public DbSet<Entities.Task> Tasks { get; set; }
    }
}
