﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agenda.BLL.Entities
{
    [Table("Usuario")]
    public class User
    {
        [Column("Id")]
        public int Id { get; set; }

        [Column("Nome")]
        public string Name { get; set; }

        [Column("Endereço")]
        public string Address { get; set; }

        [Column("CEP")]
        public string ZipCode { get; set; }

        [Column("Bairro")]
        public string Neighborhood { get; set; }

        [Column("Cidade")]
        public string City { get; set; }

        [Column("UF")]
        public string State { get; set; }

        public virtual ICollection<Schedule> Schedule { get; set; }
    }
}
