﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agenda.BLL.Entities
{
    [Table("Compromisso")]
    public class Task
    {
        [Column("Id")]
        public int Id { get; set; }

        [Column("IdAgenda")]
        public int IdSchedule { get; set; }

        [Column("Nome")]
        public string Name { get; set; }

        [Column("DataInicio")]
        public DateTime StartDate { get; set; }

        [Column("DataFim")]
        public DateTime EndDate { get; set; }

        [ForeignKey("IdSchedule")]
        public virtual Schedule Schedule { get; set; }
    }
}
