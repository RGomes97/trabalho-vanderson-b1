﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agenda.BLL.Entities
{
    [Table("Agenda")]
    public class Schedule
    {
        [Column("Id")]
        public int Id { get; set; }

        [Column("IdUsuario")]
        public int IdUser { get; set; }

        [Column("Nome")]
        public string Name { get; set; }

        [ForeignKey("IdUser")]
        public virtual User User { get; set; }

        public virtual ICollection<Task> Tasks {get; set; }
    }
}
