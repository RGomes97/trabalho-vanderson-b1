﻿using Agenda.BLL.Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agenda.BLL.Services
{
    public class UserService
    {
        private Context _ctx;
        public UserService(Context ctx)
        {
            this._ctx = ctx;
        }

        public bool Save(User user)
        {
            if (user.Id > 0)
            {
                User existing = _ctx.Users.Find(user.Id);
                if (existing != null)
                {
                    _ctx.Entry(existing).CurrentValues.SetValues(user);
                }
            }
            else
            {
                this._ctx.Users.Add(user);
            }
            return this._ctx.SaveChanges() > 0;
        }

        public bool RemoveUser(User user)
        {
            this._ctx.Users.Remove(user);
            return this._ctx.SaveChanges() > 0;

        }

        public List<User> SelectUsers()
        {
            return this._ctx.Users.ToList();
        }
    }
}
